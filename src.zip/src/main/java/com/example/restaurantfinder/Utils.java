package com.example.restaurantfinder;

public class Utils {

    public static final String DatabaseName = "data_new.db";
    public static final int DatabaseVersion = 1;
    public static final String TableName = "locations";
    public static final String ColumnId = "id";
    public static final String ColumnTitle = "name";

}
