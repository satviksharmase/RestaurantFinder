package com.example.restaurantfinder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    Context context;

    public DatabaseHelper(@Nullable Context context) {
        super(context, Utils.DatabaseName, null, Utils.DatabaseVersion);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase database)
    {
        String query = "CREATE TABLE " + Utils.TableName + " (" + Utils.ColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " + Utils.ColumnTitle + " TEXT, " + "latitude" + " VARCHAR, " + "longitude" + " VARCHAR);";
        database.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        database.execSQL("DROP TABLE IF EXISTS " + Utils.TableName);
        onCreate(database);
    }

    void addLocation(String title,double latitude,double longitude)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utils.ColumnTitle, title);
        contentValues.put("latitude", latitude);
        contentValues.put("longitude",longitude);

        long value = database.insert(Utils.TableName,null,contentValues);
        if (value == -1)
        {
            Toast.makeText(context, "Location adding failed", Toast.LENGTH_SHORT).show();

        }
        else
        {
            Toast.makeText(context, "Location adding successful", Toast.LENGTH_SHORT).show();
        }
    }

    Cursor readAllData()
    {
        String query = "SELECT * FROM " + Utils.TableName;
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = null;
        if(database!= null)
        {
            cursor = database.rawQuery(query,null);
        }
        return cursor;
    }
}
